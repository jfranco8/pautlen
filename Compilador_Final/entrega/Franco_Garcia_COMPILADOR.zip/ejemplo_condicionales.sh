
make clean
make

./pruebaCompilador ejemplos_prueba/condicionales.alfa ejemplos_prueba/condicionales_mi_salida.asm

make clean
