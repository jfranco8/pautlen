
Marta Garcia Marin
Jesus Franco Lopez

Nuestro compilador no gestiona entornos locales dentro de entornos locales,
por lo que los ejemplos de Fibonacci, Funciones y Funciones_vectores
no funcinarán.

Trabajamos con una estructura tabla de símbolos que contiene dos tablas hash
diferentes.
