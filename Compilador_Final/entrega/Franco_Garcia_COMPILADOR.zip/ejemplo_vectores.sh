
make clean
make

./pruebaCompilador ejemplos_prueba/vectores.alfa ejemplos_prueba/vectores_mi_salida.asm

make clean
