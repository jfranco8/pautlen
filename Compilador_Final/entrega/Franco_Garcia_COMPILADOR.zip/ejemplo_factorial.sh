
make clean
make

./pruebaCompilador ejemplos_prueba/factorial.alfa ejemplos_prueba/factorial_mi_salida.asm

make clean
